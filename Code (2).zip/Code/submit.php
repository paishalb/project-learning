<?php
require 'config.php'; // Panggil koneksi database

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $operator = $_POST['operator'];
    $nama = $_POST['nama'];
    $lokasi = $_POST['lokasi'];
    $permasalahan = $_POST['permasalahan'];
    $catatan = $_POST['catatan'];
    $tanggal = date("Y-m-d");

    // Generate nomor tiket unik
    $no_tiket = uniqid('TIKET-');

    // Query Insert
    $sql = "INSERT INTO submissions (no_tiket, operator, nama, lokasi, permasalahan, catatan, tanggal) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error dalam persiapan query: " . $conn->error);
    }

    $stmt->bind_param("sssssss", $no_tiket, $operator, $nama, $lokasi, $permasalahan, $catatan, $tanggal);

    if ($stmt->execute()) {
        echo "<script>alert('Data berhasil disimpan!'); window.location.href='index.php';</script>";
        exit();
    } else {
        echo "Gagal menambahkan data: " . $stmt->error;
    }
}
?>