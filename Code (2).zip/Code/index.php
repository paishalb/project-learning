<?php
require 'config.php'; // Koneksi database

// Ambil data dari database
$sql_select = "SELECT * FROM submissions ORDER BY tanggal DESC";
$result = $conn->query($sql_select);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Permasalahan</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; color: white; }

        /* Video Background */
        .video-container {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            overflow: hidden;
            z-index: -1;
        }
        .video-container video {
            width: 100%; height: 100%;
            object-fit: cover;
        }

        /* Container */
        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }
        h2, h3 { text-align: center; margin-bottom: 20px; }

        /* Form Styling */
        .form-group { display: flex; flex-direction: column; gap: 15px; }
        label { font-weight: bold; }
        input, textarea {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
        }
        input:focus, textarea:focus { outline: 2px solid #007bff; }
        button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover { background: #0056b3; }

        /* Table Styling */
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
            color: white;
        }
        th {
            background: #007bff;
            color: white;
        }
        .edit-btn, .delete-btn, .close-btn {
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            color: white;
            text-decoration: none;
            display: inline-block;
        }
        .edit-btn { background: #ffc107; }
        .delete-btn { background: #dc3545; }
        .close-btn { background: #28a745; }
        .edit-btn:hover { background: #e0a800; }
        .delete-btn:hover { background: #c82333; }
        .close-btn:hover { background: #218838; }

        /* Tombol Tutup Tiket di Pojok Kanan Atas */
        .top-right {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #28a745;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }
        .top-right:hover { background: #218838; }
    </style>
</head>
<body>

    <!-- Background Video -->
    <div class="video-container">
        <video autoplay loop muted>
            <source src="zenitsu.mp4" type="video/mp4">
            Maaf, browser Anda tidak mendukung video background.
        </video>
    </div>

    <!-- Tombol Tutup Tiket -->
    <a href="tutup_tiket.php" class="top-right">Tutup Tiket</a>

    <div class="container">
        <h2>Form Permasalahan</h2>
        <form action="submit.php" method="POST">
            <div class="form-group">
                <label for="operator">Operator:</label>
                <input type="text" id="operator" name="operator" required>

                <label for="nama">Nama:</label>
                <input type="text" id="nama" name="nama" required>

                <label for="lokasi">Lokasi:</label>
                <input type="text" id="lokasi" name="lokasi" required>

                <label for="permasalahan">Permasalahan:</label>
                <input type="text" id="permasalahan" name="permasalahan" required>

                <label for="catatan">Catatan:</label>
                <textarea id="catatan" name="catatan" required></textarea>
            </div>

            <button type="submit" name="submit">Submit</button>
        </form>
    </div>

    <div class="container">
        <h3>Data Tersimpan</h3>
        <table>
            <tr>
                <th>No urut</th>
                <th>Tanggal</th>
                <th>Operator</th>
                <th>Nama</th>
                <th>Lokasi</th>
                <th>Permasalahan</th>
                <th>Catatan</th>
                <th>Aksi</th>
            </tr>

            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['no_tiket']}</td>
                            <td>{$row['tanggal']}</td>
                            <td>{$row['operator']}</td>
                            <td>{$row['nama']}</td>
                            <td>{$row['lokasi']}</td>
                            <td>{$row['permasalahan']}</td>
                            <td>{$row['catatan']}</td>
                            <td>
                                <a href='edit.php?id={$row['id']}' class='edit-btn'>Edit</a>
                                <a href='delete.php?id={$row['id']}' onclick='return confirm(\"Yakin ingin menghapus data?\")' class='delete-btn'>Delete</a>
                               
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>Tidak ada data.</td></tr>";
            }
            ?>
        </table>
    </div>

</body>
</html>

<?php $conn->close(); ?>
