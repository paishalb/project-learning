<?php
require 'config.php'; // Koneksi database

// Jika tombol submit ditekan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $no_tiket = $_POST['no_tiket'];
    $detail_tiket = $_POST['detail_tiket'];
    $operator = $_POST['operator'];
    $status = $_POST['status'];

    // Simpan ke database
    $sql_insert = "INSERT INTO tiket_tutup (no_tiket, detail_tiket, operator, status, tanggal_tutup) 
                   VALUES ('$no_tiket', '$detail_tiket', '$operator', '$status', NOW())";

    if ($conn->query($sql_insert) === TRUE) {
        echo "<script>alert('Tiket berhasil ditutup!'); window.location='tutup_tiket.php';</script>";
    } else {
        echo "Error: " . $sql_insert . "<br>" . $conn->error;
    }
}

// Ambil data tiket yang sudah ditutup
$sql_select = "SELECT * FROM tiket_tutup ORDER BY tanggal_tutup DESC";
$result = $conn->query($sql_select);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutup Tiket</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; color: white; }

        /* Video Background */
        .video-container {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            overflow: hidden;
            z-index: -1;
        }
        .video-container video {
            width: 100%; height: 100%;
            object-fit: cover;
        }

        /* Container */
        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }
        h2, h3 { text-align: center; margin-bottom: 20px; }

        /* Form Styling */
        .form-group { display: flex; flex-direction: column; gap: 15px; }
        label { font-weight: bold; }
        input, textarea {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
        }
        input:focus, textarea:focus { outline: 2px solid #007bff; }

        /* Radio Button */
        .radio-group { display: flex; gap: 10px; margin-top: 10px; }
        .radio-group label { cursor: pointer; }

        button {
            width: 100%;
            padding: 12px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover { background: #218838; }

        /* Table Styling */
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
            color: white;
        }
        th {
            background: #28a745;
            color: white;
        }
    </style>
</head>
<body>

    <!-- Background Video -->
    <div class="video-container">
        <video autoplay loop muted>
            <source src="zenitsu.mp4" type="video/mp4">
            Maaf, browser Anda tidak mendukung video background.
        </video>
    </div>

    <div class="container">
        <h2>Tutup Tiket</h2>
        <a href="index.php" class="back-button">⬅ Kembali ke Halaman Utama</a>
        <form action="" method="POST">
            <div class="form-group">
                <label for="no_tiket">No Tiket:</label>
                <input type="text" id="no_tiket" name="no_tiket" required>

                <label for="detail_tiket">Detail Tiket:</label>
                <textarea id="detail_tiket" name="detail_tiket" required></textarea>

                <label for="operator">Operator:</label>
                <input type="text" id="operator" name="operator" required>

                <label>Status Tiket:</label>
                <div class="radio-group">
                    <input type="radio" id="sudah" name="status" value="Sudah" required>
                    <label for="sudah">Sudah</label>

                    <input type="radio" id="belum" name="status" value="Belum">
                    <label for="belum">Belum</label>

                    <input type="radio" id="pending" name="status" value="Pending">
                    <label for="pending">Pending</label>

                    <input type="radio" id="eskalasi" name="status" value="Eskalasi">
                    <label for="eskalasi">Eskalasi</label>
                </div>
            </div>

            <button type="submit">Simpan</button>
        </form>
    </div>

    <div class="container">
        <h3>Data Tiket yang Sudah Ditutup</h3>
        <table>
            <tr>
                <th>No Tiket</th>
                <th>Detail</th>
                <th>Operator</th>
                <th>Status</th>
                <th>Tanggal Tutup</th>
            </tr>

            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['no_tiket']}</td>
                            <td>{$row['detail_tiket']}</td>
                            <td>{$row['operator']}</td>
                            <td>{$row['status']}</td>
                            <td>{$row['tanggal_tutup']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>Belum ada tiket yang ditutup.</td></tr>";
            }
            ?>
        </table>
    </div>

</body>
</html>

<?php $conn->close(); ?>
