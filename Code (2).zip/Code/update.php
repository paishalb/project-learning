<?php
require 'config.php';

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $operator = $_POST['operator'];
    $nama = $_POST['nama'];
    $lokasi = $_POST['lokasi'];
    $permasalahan = $_POST['permasalahan'];
    $catatan = $_POST['catatan'];

    $sql_update = "UPDATE submissions 
                   SET operator='$operator', nama='$nama', lokasi='$lokasi', permasalahan='$permasalahan', catatan='$catatan' 
                   WHERE id=$id";

    if ($conn->query($sql_update) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Gagal mengupdate data: " . $conn->error;
    }
}

$conn->close();
?>
