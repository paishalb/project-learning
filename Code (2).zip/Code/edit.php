<?php
require 'config.php';

$id = $_GET['id'];
$sql_get = "SELECT * FROM submissions WHERE id=$id";
$result = $conn->query($sql_get);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; color: white; }

        /* Video Background */
        .video-container {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            overflow: hidden;
            z-index: -1;
        }
        .video-container video {
            width: 100%; height: 100%;
            object-fit: cover;
        }

        /* Form Container */
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
        }
        h2 { text-align: center; margin-bottom: 20px; }
        .form-group { display: flex; flex-direction: column; gap: 15px; }
        label { font-weight: bold; }
        input, textarea {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
        }
        input:focus, textarea:focus { outline: 2px solid #007bff; }
        button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover { background: #0056b3; }
        .back-btn {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #ddd;
            text-decoration: none;
        }
        .back-btn:hover { color: #fff; text-decoration: underline; }
    </style>
</head>
<body>

    <!-- Background Video -->
    <div class="video-container">
        <video autoplay loop muted>
            <source src="background.mp4" type="video/mp4">
            Maaf, browser Anda tidak mendukung video background.
        </video>
    </div>

    <div class="container">
        <h2>Edit Data</h2>
        <form action="update.php" method="POST">
            <input type="hidden" name="id" value="<?= $row['id'] ?>">

            <div class="form-group">
                <label>Operator:</label>
                <input type="text" name="operator" value="<?= $row['operator'] ?>" required>

                <label>Nama:</label>
                <input type="text" name="nama" value="<?= $row['nama'] ?>" required>

                <label>Lokasi:</label>
                <input type="text" name="lokasi" value="<?= $row['lokasi'] ?>" required>

                <label>Permasalahan:</label>
                <input type="text" name="permasalahan" value="<?= $row['permasalahan'] ?>" required>

                <label>Catatan:</label>
                <textarea name="catatan" required><?= $row['catatan'] ?></textarea>
            </div>

            <button type="submit" name="update">Update Data</button>
        </form>
        <a href="index.php" class="back-btn">← Kembali</a>
    </div>

</body>
</html>
