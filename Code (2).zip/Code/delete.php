<?php
require 'config.php';

$id = $_GET['id']; // Ambil ID dari URL

$sql_delete = "DELETE FROM submissions WHERE id=$id";

if ($conn->query($sql_delete) === TRUE) {
    header("Location: index.php");
} else {
    echo "Gagal menghapus data: " . $conn->error;
}

$conn->close();
?>
